﻿using System;
using System.IO;
using AppKit;
using Foundation;
using SIDGIN.Patcher.SelfUpdate;
using SIDGIN.Patcher.Standalone;

namespace SelfUpdate
{
    public partial class ViewController : NSViewController
    {
        public ViewController(IntPtr handle) : base(handle)
        {
        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            Start();
            // Do any additional setup after loading the view.
        }

        public override NSObject RepresentedObject
        {
            get
            {
                return base.RepresentedObject;
            }
            set
            {
                base.RepresentedObject = value;
                // Update the view, if already loaded.
            }
        }
        public static string MAIN_CLIENT_FOLDER
        {
            get
            {
                string directory = AppDomain.CurrentDomain.BaseDirectory;
                directory = Directory.GetParent(directory).ToString();
                directory = Directory.GetParent(directory).ToString();
                directory = Directory.GetParent(directory).ToString();
                return directory;
            }
        }
        async void Start()
        {
            if (!SingleInstanceControl.CheckInstance())
            {

                ShowMessage("Please close the game client and restart.");
                Environment.Exit(0);
                return;
            }
            try
            {
                SelfUpdateClient.preparingExecutable += OnPrepareExec;
                await SelfUpdateClient.StartLauncher(Path.Combine(MAIN_CLIENT_FOLDER, "launcher.config"));
            }
            catch (Exception ex)
            {
                ShowMessage(ex.Message);
            }
            finally
            {
                NSApplication.SharedApplication.Terminate(NSApplication.SharedApplication);
            }
        }

        private void OnPrepareExec(string execPath)
        {
            string directory = AppDomain.CurrentDomain.BaseDirectory;
            directory = Directory.GetParent(directory).ToString();
            directory = Directory.GetParent(directory).ToString();
            var resources = Path.Combine(directory, "Resources");
            MacAccessRightsHelper.GrantAccessRights(resources, execPath);
        }

        public static void ShowMessage(string error)
        {
            var alert = new NSAlert();
            alert.MessageText = "Error";
            alert.InformativeText = error;
            alert.AddButton("OK");
            alert.RunModal();

        }
    }
}
