﻿using System;
using System.Diagnostics;
using System.IO;

namespace SIDGIN.Patcher.VSClientMac
{
    public static class ClientConsts
    {
        public static string MAIN_CLIENT_FOLDER
        {
            get
            {
                string directory = AppDomain.CurrentDomain.BaseDirectory;
                directory = Directory.GetParent(directory).ToString();
                directory = Directory.GetParent(directory).ToString();
                directory = Directory.GetParent(directory).ToString();
                directory = Directory.GetParent(directory).ToString();
                return directory;
            }
        }
        public static string LOCALIZE_FOLDER
        {
            get
            {
                var fileName = Path.GetFileName(Process.GetCurrentProcess().MainModule.FileName) + ".app";
                return Path.Combine(ClientConsts.MAIN_CLIENT_FOLDER, fileName, "loc");
            }
        }
        public const string VERSIONS_FILE_NAME = "VERSIONS";
        public const string VERSION_FILE_NAME = "VERSION";
    }
}
