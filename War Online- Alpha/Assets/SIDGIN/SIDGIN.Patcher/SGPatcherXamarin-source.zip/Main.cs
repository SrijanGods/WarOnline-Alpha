﻿using AppKit;

namespace SIDGIN.Patcher.VSClientMac
{
    static class MainClass
    {
        static void Main(string[] args)
        {
            NSApplication.Init();
            Xamarin.Forms.Forms.Init();
            NSApplication.Main(args);

        }

    }
}
