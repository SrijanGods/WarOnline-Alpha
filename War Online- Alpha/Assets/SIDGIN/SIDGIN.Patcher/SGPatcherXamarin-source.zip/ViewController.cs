﻿using System;
using System.Threading;
using System.Diagnostics;

using AppKit;
using Foundation;
using Xamarin.Forms;

namespace SIDGIN.Patcher.VSClientMac
{
    using Configurator;
    using Client;
    using SIDGIN.Patcher.Storages;

    public partial class ViewController : NSViewController
    {
        public int i;
        public ViewController(IntPtr handle) : base(handle)
        {
        }
        //identical to MainWindow method in VSClient
        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            Start();

            // Do any additional setup after loading the view.
        }

        public override NSObject RepresentedObject
        {
            get
            {
                return base.RepresentedObject;
            }
            set
            {
                base.RepresentedObject = value;
                // Update the view, if already loaded.
            }
        }
        public double setProgressIndicatorValue(NSProgressIndicator prog, float flo)
        {
            double currentValue = prog.DoubleValue;
            double newValue = (double)flo;
            double increment = newValue - currentValue;
            return increment;
        }

        void MainProgress(PatcherProgress p)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                upperProgressString.StringValue = p.status;
                double increment = setProgressIndicatorValue(upperProgressBar, p.progress) * 100;
                float percents = p.progress * 100;
                percents = (float)Math.Round(percents, 2, MidpointRounding.AwayFromZero);
                upperProgressBar.DoubleValue = percents;
            });
        }
        ConfigurationBuilder GetConfigurationBuilder()
        {
            string data;
            var fileName = System.IO.Path.GetFileName(Process.GetCurrentProcess().MainModule.FileName) + ".app";
            var configFilePath = System.IO.Path.Combine(ClientConsts.MAIN_CLIENT_FOLDER, fileName, "patcher.config");
            if (System.IO.File.Exists(configFilePath))
            {
                data = System.IO.File.ReadAllText(configFilePath);
            }
            else
            {
                throw new InvalidConfigurationException(209);
            }
            return new ConfigurationBuilder(data);
        }
        async void Start()
        {

            try
            {

                var configBuilder = GetConfigurationBuilder();
                var clientSettings = configBuilder.GetData<ClientSettings>();
                if (clientSettings == null)
                {
                    clientSettings = new ClientSettings();
                }
                clientSettings.targetDirectory = ClientConsts.MAIN_CLIENT_FOLDER;
                clientSettings.localizeDirectory = ClientConsts.LOCALIZE_FOLDER;

                var config = configBuilder.Add(clientSettings).Compile();
                try
                {
                    var patcher = new PatcherClient(config);
                    patcher.onProgressChanged += MainProgress;

                    await patcher.Update(new CancellationToken());

                    MacAccessRightsHelper.GrantAccessRights(ClientConsts.MAIN_CLIENT_FOLDER, clientSettings.executeFileName);
                    var applicationLauncher = new ApplicationLauncher(config);
                    applicationLauncher.Launch();
                }
                catch (Exception ex)
                {
                    if (clientSettings.offlineMode)
                    {
                        if (ex is UnableConnectToServer || ex is UnableLoadResource)
                        {
                            MacAccessRightsHelper.GrantAccessRights(ClientConsts.MAIN_CLIENT_FOLDER, clientSettings.executeFileName);
                            var applicationLauncher = new ApplicationLauncher(config);
                            applicationLauncher.Launch();
                        }
                        else
                        {
                            throw ex;
                        }
                    }
                    else
                    {
                        throw ex;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandler.Show(ex.Message);
                return;
            }
            finally
            {
                NSApplication.SharedApplication.Terminate(NSApplication.SharedApplication);
            }
        }
    }

}