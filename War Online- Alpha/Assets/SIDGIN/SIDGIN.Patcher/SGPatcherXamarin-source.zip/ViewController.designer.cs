// WARNING
//
// This file has been generated automatically by Visual Studio to store outlets and
// actions made in the UI designer. If it is removed, they will be lost.
// Manual changes to this file may not be handled correctly.
//
using Foundation;
using System.CodeDom.Compiler;

namespace SIDGIN.Patcher.VSClientMac
{
	[Register ("ViewController")]
	partial class ViewController
	{
		[Outlet]
		AppKit.NSProgressIndicator lowerProgressBar { get; set; }

		[Outlet]
		AppKit.NSTextField lowerProgressString { get; set; }

		[Outlet]
		AppKit.NSButton MyButton { get; set; }

		[Outlet]
		AppKit.NSTextField updateString { get; set; }

		[Outlet]
		AppKit.NSProgressIndicator upperProgressBar { get; set; }

		[Outlet]
		AppKit.NSTextField upperProgressString { get; set; }
		
		void ReleaseDesignerOutlets ()
		{
			if (lowerProgressBar != null) {
				lowerProgressBar.Dispose ();
				lowerProgressBar = null;
			}

			if (lowerProgressString != null) {
				lowerProgressString.Dispose ();
				lowerProgressString = null;
			}

			if (MyButton != null) {
				MyButton.Dispose ();
				MyButton = null;
			}

			if (updateString != null) {
				updateString.Dispose ();
				updateString = null;
			}

			if (upperProgressBar != null) {
				upperProgressBar.Dispose ();
				upperProgressBar = null;
			}

			if (upperProgressString != null) {
				upperProgressString.Dispose ();
				upperProgressString = null;
			}
		}
	}
}
