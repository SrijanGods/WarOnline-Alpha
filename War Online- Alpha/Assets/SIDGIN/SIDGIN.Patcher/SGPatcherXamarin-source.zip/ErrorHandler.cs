﻿using AppKit;

namespace SIDGIN.Patcher.VSClientMac
{
    public static class ErrorHandler
    {
        public static void Show(string error)
        {
            var alert = new NSAlert();
            alert.MessageText = "Error";
            alert.InformativeText = error;
            alert.AddButton("OK");
            alert.RunModal();
            NSApplication.SharedApplication.Terminate(NSApplication.SharedApplication);
        }
    }
}
