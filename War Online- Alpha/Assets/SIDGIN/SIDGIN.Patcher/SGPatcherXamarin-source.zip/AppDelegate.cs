﻿using AppKit;
using Foundation;

namespace SIDIGN.Patcher.VSClientMac
{
    [Register("AppDelegate")]
    public class AppDelegate : NSApplicationDelegate
    {
        public AppDelegate()
        {
        }

        public override void DidFinishLaunching(NSNotification notification)
        {
            //Xamarin.Forms.Forms.Init();
            //NSApplication.SharedApplication.MainWindow.Center();
            // Insert code here to initialize your application
        }

        public override void WillTerminate(NSNotification notification)
        {
            // Insert code here to tear down your application
        }
    }
}
