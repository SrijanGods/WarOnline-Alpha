﻿using System;
using System.IO;

namespace SIDGIN.Patcher.VSClient
{
    public static class ClientConsts
    {
        public static string MAIN_CLIENT_FOLDER
        {
            get
            {
                
                return AppDomain.CurrentDomain.BaseDirectory;
            }
        }
        public static string LOCALIZE_FOLDER
        {
            get
            {

                return Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"loc");
            }
        }
        public const string VERSIONS_FILE_NAME = "VERSIONS";
        public const string VERSION_FILE_NAME = "VERSION";
    }
}
