﻿using SIDGIN.Patcher.Standalone;
using System.Windows;

namespace SIDGIN.Patcher.VSClient
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        public void OnStart(object sender, StartupEventArgs e)
        {
            if (!SingleInstanceControl.CheckInstance())
            {
                MessageBox.Show("Please close the game client and restart.");
                Application.Current.Shutdown();
            }
        }

        private void Application_Exit(object sender, ExitEventArgs e)
        {
            SingleInstanceControl.Dispose();
        }
    }


}
