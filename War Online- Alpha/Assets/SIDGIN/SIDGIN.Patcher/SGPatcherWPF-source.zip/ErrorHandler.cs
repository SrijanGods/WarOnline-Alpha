﻿using System.Windows;

namespace SIDGIN.Patcher.VSClient
{
    public static class ErrorHandler
    {
        public static void Show(string error)
        {
            MessageBox.Show(error, "Error", MessageBoxButton.OK,MessageBoxImage.Error);
            Application.Current.Shutdown();
        }
    }
}
