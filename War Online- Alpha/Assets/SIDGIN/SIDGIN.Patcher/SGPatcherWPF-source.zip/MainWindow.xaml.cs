﻿using System;
using System.Threading;
using System.Windows;
using System.Windows.Media;

namespace SIDGIN.Patcher.VSClient
{
    using Client;
    using Configurator;
    using SIDGIN.Patcher.Standalone;
    using SIDGIN.Patcher.Storages;
    using System.Globalization;

    public partial class MainWindow : Window
    {
         Color borderColor = Color.FromRgb(0, 0, 0);
        public MainWindow()
        {
            InitializeComponent();
            WindowStartupLocation = System.Windows.WindowStartupLocation.CenterScreen;
            MainBorder.BorderBrush = new SolidColorBrush(borderColor);
            Start();
        }

        void MainProgress(PatcherProgress progress)
        {
            Dispatcher.BeginInvoke((Action)(() =>
            {
                Status1.Content = progress.status;
                Progress1.Value = progress.progress * 100f;
            }));
        }
        ConfigurationBuilder GetConfigurationBuilder()
        {
            string data;
            if (System.IO.File.Exists("patcher.config"))
            {
                data = System.IO.File.ReadAllText("patcher.config");
            }
            else
            {
                throw new InvalidConfigurationException(209);
            }

            return new ConfigurationBuilder(data);
        }
        async void Start()
        {

            try
            {
                var configBuilder = GetConfigurationBuilder();
                var clientSettings = configBuilder.GetData<ClientSettings>();
                if (clientSettings == null)
                {
                    clientSettings = new ClientSettings();
                }
                clientSettings.targetDirectory = ClientConsts.MAIN_CLIENT_FOLDER;
                clientSettings.localizeDirectory = ClientConsts.LOCALIZE_FOLDER;

                var config = configBuilder.Add(clientSettings).Compile();
                try
                {
                    var ucPatcher = new PatcherClient(config);
                    ucPatcher.onProgressChanged += MainProgress;

                    await ucPatcher.Update(new CancellationToken());
                    var applicationLauncher = new ApplicationLauncher(config);
                    applicationLauncher.Launch();
                }
                catch(Exception ex)
                {
                    if (clientSettings.offlineMode)
                    {
                        if (ex is UnableConnectToServer || ex is UnableLoadResource)
                        {
                            var applicationLauncher = new ApplicationLauncher(config);
                            applicationLauncher.Launch();
                        }
                        else
                        {
                            throw ex;
                        }
                    }
                    else
                    {
                        throw ex;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandler.Show(ex.Message);
                return;
            }
            finally
            {
                Application.Current.Shutdown();
            }
        }
    }
}
