﻿using SIDGIN.Patcher.Standalone;
using System;
using System.Runtime.InteropServices;
namespace SIDGIN.Patcher.SelfUpdate.VS
{
    class Program
    {

        [DllImport("User32.dll", CharSet = CharSet.Unicode)]
        public static extern int MessageBox(IntPtr h, string m, string c, int type);
        static void Main(string[] args)
        {
            if (!SingleInstanceControl.CheckInstance())
            {

                MessageBox((IntPtr)0, "Please close the game client and restart.", "Multiple instances", 0);
                Environment.Exit(0);
                return;
            }
            Console.WriteLine("Check launcher updates...");
            Console.SetWindowSize(100, 5);
            StartSelfUpdate();
            Console.ReadLine();
        }
        static async void StartSelfUpdate()
        {
            try
            {
                await SelfUpdateClient.StartLauncher();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                Console.ReadLine();
            }
            finally
            {
                Environment.Exit(0);
            }
        }
    }
}
